<template>
  <div class="page-article" v-if="model">
    <div class="d-flex">
      <div class="iconfont icon-menu"></div>
      <div class="flex-1">
        {{ model.title }}
      </div>
      <div class="text-grey fs-xm">
        2019-2-16
      </div>
    </div>
  </div>
</template>

<script>
export default {
  props: {
    id: {
      required: true
    }
  },
  data() {
    return {
      model: null
    }
  },
  created() {
    this.fetch();
  },
  methods: {
    async fetch() {
      const res = await this.$http.get(`articles/${this.id}`);
      this.model = res.data;
    }
  }
}
</script>